# Game Physco Preview Build

This is a repaired previewable build created from the usable scenario-pack data inside the uploaded ZIP.

## Fast open
Open `index.html` directly in a browser.

## Local preview server
From this folder:

```bash
python3 -m http.server 5173
```

Then open:

```text
http://localhost:5173
```

## Vite preview/dev option
If you want Vite:

```bash
npm install
npm run dev
```

## What was fixed
- Turned the loose exported Lovable/chat archive into a real single-page game preview.
- Added a working start screen, pack selection, question flow, scoring, results, and partner-compatibility mode.
- Embedded all scenario data so the app can run even when opened directly from the file system.
- Kept the editable JSON scenario packs in `/data`.

## Note
The psychopathy scoring is entertainment/game logic only. It is not a clinical diagnostic tool.
